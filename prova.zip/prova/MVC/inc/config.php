<?php
define("SERVIDOR", "mysql:host=localhost;port=3306; dbname=receitas; charset=utf8");
define("USUARIO", "root");
define("SENHA", "");

?>